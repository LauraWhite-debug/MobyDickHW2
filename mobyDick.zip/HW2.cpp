#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include <sstream>
using namespace std;

// structure keeps track of the word and its count
struct wordRecord
{
    string word;
    int count;
};
// add ignore words from file to string array 
void getIgnoreWords(const char *ignoreWordFileName, string ignoreWords[])
{
    ifstream ignoreFile;
    string line = "";
    ignoreFile.open(ignoreWordFileName); //open file
    if(ignoreFile.is_open())
    {
        int i = 0;
        while(getline(ignoreFile, line))
        {
            ignoreWords[i] = line;
            i++;
        }
        ignoreFile.close();
    }
    else
    {
        cout << "Failed to open " << ignoreWordFileName << endl; 
    }
}
// check if a word is ignore word
bool isIgnoreWord(string word, string ignoreWords[])
{
    for(int i=0; i<50; i++)
    {
        if(ignoreWords[i] == word)
        {
            return true;
        }
    }
    return false;
}
// return sum of distinct words
int getTotalNumberNonIgnoreWords(wordRecord distinctWords[], int length)
{
    int sum = 0;
    for(int i=0; i<length; i++)
    {
        sum += distinctWords[i].count; // add each count for each unique word to sum
    }
    return sum;
}
// sort array with most frequent at beginning
void sortArray(wordRecord distinctWords[], int length)
{
    for(int i=0; i<length; i++)
    {
        for(int j=i+1; j<length; j++)
        {
            if(distinctWords[i].count < distinctWords[j].count) // if count at i is less than count at j
            {
                wordRecord temp = distinctWords[i]; // temp wordRecord struct to hold distinctWords at i
                distinctWords[i] = distinctWords[j]; // move distinctWords at i up one index
                distinctWords[j] = temp; // set distinct words at i to temp struct
            }
            // if the count at both i and j are equal and the first letter of the word at i is greater than that at j
            else if(distinctWords[i].count == distinctWords[j].count && (distinctWords[i].word[0] > distinctWords[j].word[0]))
            {
                wordRecord temp = distinctWords[i]; // temp wordRecord struct to hold distinctWords at i
                distinctWords[i] = distinctWords[j]; // move distinctWords at i up one index
                distinctWords[j] = temp; // set distinct words at i to temp struct
            }
        }
    }
}
// print next 10 words after starting index N from sorted array
void printTenFromN(wordRecord distinctWords[], int N, int totalNumWords)
{
    float occurenceProbability; 
    cout << setprecision(5) << fixed;

    for(int i=N; i<N+10; i++)
    {
        occurenceProbability = (float)distinctWords[i].count/totalNumWords;
        cout << occurenceProbability << " - " << distinctWords[i].word << endl;
    }   
}
int main(int argc, char* argv[]) // takes N starting index, file name to be read, filename to be ignored
{
    string ignoreWords[50]; // array of 50 ignore words
    wordRecord *distinctWords; // wordRecord pointer
    distinctWords = new wordRecord[100]; // array of 100 wordRecord structs
    int doubleArr = 0; // how many times the array is doubled
    int distArrCap = 100; // capacity
    int currDistArrSize = 0; // current array size
    bool alreadyInArr;
    if(sizeof(argc) != 4) // if 4 arguments are not entered
    {
        cout << "Usage: Assignment2Solution <number of words> <inputfilename.txt> <ignoreWordsfilename.txt>" << endl;
    }
    else
    {
        getIgnoreWords(argv[3], ignoreWords); // call getIgnoreWords from fourth command line argument (ignoreFile.txt)
        ifstream bigText;
        string line = "";
        string word;
        bigText.open(argv[2]); // open big file to read
        if(bigText.is_open())
        {
            while(getline(bigText, line)) // loop through lines of file
            {
                stringstream ss(line); // treat line as a string
                while(getline(ss, word, ' ')) // loop through each word in line
                {
                    if(word.length() > 0) // skipping empty lines
                    {
                        alreadyInArr = false; // set already in array tracker to false
                        if(isIgnoreWord(word, ignoreWords) == false) // if word is not ignore word, add to wordRecord struct
                        {
                            if(currDistArrSize < distArrCap) // as long as there's room in array
                            {
                                for(int i=0; i<currDistArrSize; i++) // loop through distinct array
                                {
                                    if(distinctWords[i].word == word) // if distinct word is aready in array, increase count
                                    {
                                        distinctWords[i].count++;
                                        alreadyInArr = true;
                                        break;
                                    }
                                }
                                if(!alreadyInArr)// if not already in array, add to end of array
                                {
                                    distinctWords[currDistArrSize].word = word;
                                    distinctWords[currDistArrSize].count = 1;
                                    currDistArrSize++; // increase array size   
                                }  
                            }
                            else // if array is full, double array capacity
                            {
                                doubleArr++; // tracks how many times array is doubled
                                wordRecord *tempArr = new wordRecord[distArrCap*2]; // create new array double size of previous array 
                                for(int j=0; j<currDistArrSize; j++) // store values of distinct array into temp array
                                {
                                    tempArr[j] = distinctWords[j];
                                }
                                delete[] distinctWords; // delete old array
                                distArrCap = distArrCap*2; // double array capacity
                                distinctWords = new wordRecord[distArrCap]; // create new array with updated capacity
                                for(int j=0; j<currDistArrSize; j++) // add values to new distinct array
                                {
                                    distinctWords[j] = tempArr[j];
                                }
                                delete[] tempArr; // delete temp array
                                
                                for(int i=0; i<currDistArrSize; i++) // loop through distinct array
                                {
                                    if(distinctWords[i].word == word) // if distinct word is aready in array, increase count
                                    {
                                        distinctWords[i].count++;
                                        alreadyInArr = true;
                                        break;
                                    }
                                }
                                if(!alreadyInArr)// if not already in array, add to end of array
                                {
                                    distinctWords[currDistArrSize].word = word;
                                    distinctWords[currDistArrSize].count = 1;
                                    currDistArrSize++; // increase array size   
                                }
                            }
                        }
                    }
                }
            }
            cout << "Array doubled: " << doubleArr << endl;
            cout << "Distinct non-common words: " << currDistArrSize << endl;
            cout << "Total non-common words: " << getTotalNumberNonIgnoreWords(distinctWords, currDistArrSize) << endl;
            sortArray(distinctWords,currDistArrSize);
            cout << "Probability of next 10 words from rank " << argv[1] << endl;
            cout << "---------------------------------------" << endl;
            printTenFromN(distinctWords, stoi(argv[1]), getTotalNumberNonIgnoreWords(distinctWords, currDistArrSize));
        }
    }
    return 0;
}